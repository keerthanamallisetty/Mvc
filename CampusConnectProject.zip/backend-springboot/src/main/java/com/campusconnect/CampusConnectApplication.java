
package com.campusconnect;
public class CampusConnectApplication {
  public static void main(String[] args){
    System.out.println("CampusConnect");
  }
}
