# CampusConnect
College social media project scaffold.
Frontend: React
Backend: Spring Boot + JWT (starter structure)
Database: MySQL
