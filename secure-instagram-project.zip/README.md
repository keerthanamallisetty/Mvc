# Secure Instagram-like Project Starter

Included security layers:
- Spring Security
- JWT placeholder structure
- BCrypt password hashing
- Role-based access control
- Input validation placeholder
- Secure API configuration

This is a starter project skeleton for further development.
