package com.example.security;

public class SecurityConfig {
    // Spring Security configuration placeholder
}
